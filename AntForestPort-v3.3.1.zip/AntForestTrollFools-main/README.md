# AntForest TrollFools Port

基于iOS巨魔插件的支付宝蚂蚁森林能量自动收取插件，支持巨魔商店 TrollStore + 巨魔注入器 TrollFools 。它不依赖 MobileSubstrate、Theos 或 CaptainHook，使用 Objective-C Runtime Hook 构建为 `arm64 + arm64e` 通用 dylib。

## 来源与致谢

本项目基于 [qsirwyk/AntForestOneCollect](https://github.com/qsirwyk/AntForestOneCollect) 二次开发，保留原项目的 MIT 许可证与版权声明。感谢原作者 qsirwyk 的开源贡献。

> 请自行评估账号、服务规则与设备安全风险。本项目不提供绕过风控或安全机制的功能。

## 效果图

| 收取记录面板（v3.2.7 正式版） | 功能设置面板 |
| :---: | :---: |
| ![收取记录面板](docs/ui-preview.png) | ![功能设置面板](docs/ui-settings.png) |

功能包括：

- 右侧悬浮叶子按钮：首页首次打开或从后台返回后完整显示；静置约 2 秒自动贴边缩小。左侧向右滑、右侧向左滑可展开，拖动位置会保存在本机。
- 收取记录面板：紧凑统计与四项收取控制；通过右上角“功能设置”管理定时收取、好友浇水和赚能量开关；支持“清空日志”与“复制日志”。
- 自动收取总开关：控制常规自动收取；关闭后好友/自己收取、后台循环与定时收取都会暂停。
- 收取自己能量：独立开关；开启后每轮优先查询并提交自己的成熟能量收取，再继续扫描好友能量。
- 自动能量雨：可独立开关；开启后进入能量雨并点击“立即开启”，插件会自动点击屏幕内正在下降的能量。
- 自动赚能量（打地鼠玩法）：在“功能设置”独立开关；手动进入并开启活动后，自动识别活动 Canvas 内出现的好友头像并点击；仅在活动专用页面生效，不影响森林首页收取。
- 循环收取（面板中显示为“后台循环”）：可独立开关；支持设置 1～60 分钟间隔，默认 5 分钟；当前以森林首页前台运行作为可靠使用条件。
- 定时收取：在“功能设置”独立开关；在设置的时间点触发整点秒级收取。
- 好友浇水：支持手动、定时与打开蚂蚁森林自动浇水三种模式；可配置每位好友浇水克数（10g / 18g / 33g / 66g）与目标好友列表。
- 神奇海洋（自动任务）：独立开关；自动扫描海洋日常任务、拼图任务并一键完成与领奖。
- 领奖励 & 森林寻宝：独立开关；自动完成每日签到、安全浏览/逛一逛任务，并自动领取今日累计阶梯大奖；手动进入寻宝活动页面后自动执行大奖抽奖。支持自定义每日开始时间。
- AI摸鱼：独立开关；自动完成摸鱼日常任务与涂鸦机会领取。
- 蚂蚁庄园：独立开关；自动每日签到、小课堂智能满分答题、智能防重喂养、自动收取小鸡金色肥料，以及一键批量领取已完成的饲料奖励。
- 新版保护地（大富翁）：独立开关；手动进入保护地后自动巡护走步、科普满分答题、步数兑换、最优物种派遣与碎片合成。
- 首页动物在岗巡护能量：实时自动感知保护地动物在岗巡护产出的能量球并自动收取入账。
- 自动复活好友过期能量：独立开关；扫描好友排行榜时自动复活好友可复活的过期能量。
- 保护罩检测：精准识别好友是否处于能量保护罩中，自动跳过不可收好友。
- 收取日志：最新记录显示在顶部；保留开关状态、本轮扫描开始/结束、浇水赠能、好友浇水和成功收取结果，并区分自己与好友能量。
- 能量统计：今日显示 g；累计满 1,000 g 后按两位小数换算为 kg；收取成功回包会去重计入统计。

> v3.2.7 正式版：iOS 15 及以上请使用 [`AntForestPort-v3.3.1.dylib`](build/AntForestPort-v3.3.1.dylib)；iOS 14 请使用独立兼容包 [`AntForestPort-v3.3.1-iOS14.dylib`](build/AntForestPort-v3.3.1-iOS14.dylib)。彻底隔离 1v1 能量挑战（`pvpHome.html`）与 PK 榜视图，解决 1v1 能量挑战卡在“稍等片刻...”及 PK 榜卡死问题，同时确保好友过期能量自动复活（`+5g`）稳定执行。产物均为 `arm64 + arm64e` 通用 dylib。

## v3.2.7 正式版更新说明

- **✨ 彻底修复 1v1 能量挑战（`pvpHome.html`）卡在“稍等片刻...”与 PK 榜卡死问题**：
  - **1v1 能量挑战与 PK 子页面零干扰隔离**：精准识别 `pvpHome.html`、`pvpRecord.html`、`pkContestRank.html`、`pkFindEnergy.html` 等子页面，防止插件将其 `PSDJsBridge` 误绑为森林任务/首页桥接并注入后台任务 RPC，确保 1v1 能量挑战与 PK 榜秒开无卡顿；
  - **正式包启用 `_doFlushMessageQueue:url:` 追踪与 `queryPvpHomeInfo` 特征识别**：出站与入站双向识别 PK/1v1 挑战请求与回包，严格保护前端独立视图状态；
  - **后台静默 RPC 净空隔离与自动复活（`+5g`）全链路保障**：对后台 `af_silent_` 静默请求返回纯净空成功回包，杜绝 `nextAction="Friend"` 跨页污染首页榜单，同时确保纯净总榜回包 100% 自动触发好友过期能量复活（`+5g`）。
- 🏷️ 控制板版本号规范更新：控制板主标题下正式更新为 `当前版本：v3.2.7 正式版`。

## 使用限制

- 退到桌面后不保证 H5/RPC 回包及实际收取；回到蚂蚁森林首页时会立即尝试补跑一次。

## 锁屏后的有限后台执行（v3.3.1）

- 进入后台/锁屏时，向 iOS 申请一次系统管理的有限后台执行时间，用于当前已开始工作的短暂收尾。
- 收到系统到期回调后立即结束后台任务并记录日志；不循环续期、不播放静音音频伪装后台运行，也不修改角标维持执行。
- 回到前台时结束尚未到期的后台任务，并恢复原有前台调度流程。
- iOS 可随时缩短或终止后台时间；到期后插件不会保证 H5/WebView、RPC 或自动收取继续执行。系统之后是否重新唤醒应用由 iOS 决定。
- 该机制不是后台常驻，也不会创建独立 Daemon。需要长期可靠的定时工作，应使用 iOS 正式支持的后台任务 API/系统调度能力；注入式 dylib 本身不能注册成独立后台应用。

设备控制台可搜索以下日志确认状态：
- `[AntForestPort] finite background task started`
- `[AntForestPort] finite background time expired`
- `[AntForestPort] foreground restored`

## iOS 14 独立版本

- iOS 14 请使用独立包 `AntForestPort-v3.3.1-iOS14.dylib`；该兼容包包含 v3.2.7 正式全部功能，不替代 iOS 15+ 的标准包。
- 该包移除了 iOS 15 才提供的 `UISheetPresentationControllerDetent` 与 `customDetent` 引用，面板使用 iOS 14 可用的标准 PageSheet。
- 已在 iPhone 12 Pro Max、iOS 14.2.1、支付宝 12.12.10、TrollFools 环境完成注入与功能验证。

## 使用说明

1. 使用巨魔注入器 TrollFools 注入 [`AntForestPort-v3.3.1.dylib`](build/AntForestPort-v3.3.1.dylib) 到支付宝。
2. 注入前移除旧的 `AntForestProbe.dylib` 或旧版插件，避免两个 dylib 同时 Hook 同一方法。
3. 完全杀掉并重开支付宝，进入蚂蚁森林。
4. 点击右侧叶子按钮；需要调整位置时，直接拖动叶子图标。静置约 2 秒后叶子会自动贴边缩小；左侧向右滑、右侧向左滑可再次展开。
5. 在收取记录面板中按需打开“自动收取”、“收取自己能量”和“自动能量雨”。“收取自己能量”仅在自动收取已开启时生效；能量雨保持独立。面板中的“复制日志”仅导出正式收取记录。
6. “后台循环”可单独开关，点击分钟按钮可设置 1～60 分钟间隔；在蚂蚁森林首页前台时，首次开启自动收取且后台循环已开启会立即执行一次。
7. 点击右上角齿轮进入“功能设置”：可管理多个每日固定收取时刻（点选修改、左滑删除）、“好友浇水设置”、“神奇海洋（自动任务）”、“领奖励 & 森林寻宝”、“AI摸鱼”、“蚂蚁庄园”、“新版保护地（大富翁）”、“赚能量（打地鼠玩法）”和“自动复活好友过期能量”独立开关。好友浇水支持手动执行、定时执行，以及“打开蚂蚁森林自动浇水”独立开关。
8. 如需收取能量雨，进入能量雨页面并手动点击“立即开启”；开始后无需再手动点击雨滴。
9. 如需使用赚能量，手动进入并开启活动；活动开始后无需手动点击好友头像，插件会自动处理当前局。该玩法每日机会由支付宝规则控制。
   如出现没有自动收集能量雨滴，立即退出能量雨界面，保留能量雨次数，不妨碍下次使用。
   
设备控制台出现下列日志，表示注入入口已安装：

```text
[AntForestPort] installed: view=1 appearance=1 response=1
```

## 巨魔真后台（可选）

`AntForestPort` 自身不提供 iOS 后台保活。可配合
[ImmortalizerJailed](https://github.com/sergealagon/ImmortalizerJailed) 尽量减少支付宝进程被系统挂起或终止的情况，但不能保证支付宝 H5/WebView 在退到桌面后继续处理 RPC 回包。

### 为什么无法保证真后台运行？

iOS 不像 Android 一样允许用户为第三方工具授予“无障碍服务”权限，以读取其他 App 的界面节点、执行手势点击或提供跨 App 悬浮控制。对普通 App 而言，iOS 不开放跨 App 的界面层级读取、全局点击/手势注入和持续后台执行权限。

TrollStore 与 TrollFools 解决的是安装、签名绕过和向目标 App 注入 dylib 的问题，并不会自动获得这些系统级权限。因此，即使支付宝进程和插件定时器仍被保活，系统仍可能暂停离屏 H5/WebView 的网络回包与页面执行；这也是退到桌面后无法承诺稳定收取的根本原因。

后台使用步骤：

1. 使用 TrollFools 同时向支付宝注入 `AntForestPort-v3.3.1.dylib` 和 `ImmortalizerJailed.dylib`。
2. 完全杀掉并重新打开支付宝，进入蚂蚁森林首页。
3. 点击叶子按钮，在收取记录面板中开启“自动收取”。
4. 点击 ImmortalizerJailed 的浮动按钮启用保活。
5. 保持蚂蚁森林首页为当前页面；需要离开时可退到桌面，但不要从多任务界面划掉支付宝。

注意：

- 已观察到：退到桌面后，进程和循环定时器可能仍在运行，但 H5/RPC 回包可能暂停，因此不能承诺后台实际收取。
- 目前可靠行为是：保持蚂蚁森林首页在前台；从桌面回到森林首页后，插件会在 Bridge 就绪时立即尝试补跑一次。
- 后台循环默认间隔为 5 分钟，可调整为 1～60 分钟；首次开启开关时会立即执行一次。
- 能量雨依赖可见的 WebGL 页面和触摸事件，仍需在前台进入能量雨并点击“立即开启”。
- 真后台会持续占用 CPU、网络和电量，请根据需要启用。
- `ImmortalizerJailed` 使用 GPL-3.0 许可证，本项目不打包或再分发该 dylib，请从其官方仓库获取并单独注入。

## 当前兼容范围

发布产物均为 `arm64 + arm64e` 通用 dylib：

| 项目 | 当前状态 |
| --- | --- |
| CPU 架构 | A11 及以下使用 `arm64`；A12 及以上使用 `arm64e` |
| iOS | 标准 v3.3.0 包支持 iOS 15 及以上；iOS 14 继续使用独立 `AntForestPort-v3.3.1-iOS14.dylib` |
| 屏幕尺寸 | 使用 Auto Layout；标准版、Plus、Pro、Pro Max 均应自适应 |
| 非越狱 | 需要巨魔商店 TrollStore 与巨魔注入器 TrollFools 都支持目标系统 |
| 越狱 | 可手动注入 dylib；暂未提供 rootful/rootless `.deb` 包 |

“支持巨魔商店 TrollStore”并不等于必然兼容：巨魔注入器 TrollFools 的注入能力、支付宝版本、私有类和响应字段也必须匹配。

典型设备：iPhone X、iPhone 8/8 Plus、iPhone 7 等为 `arm64`；iPhone XS/XR、iPhone 11 至 iPhone 16 系列为 `arm64e`。

## 已验证环境

以下是探针及正式移植版的真机验证结果：

| 项目 | 结果 |
| --- | --- |
| 设备 | iPhone 14 Pro（A16，`arm64e`） |
| 系统 | iOS 16.2 |
| 安装环境 | 非越狱：巨魔商店 TrollStore + 巨魔注入器 TrollFools |
| 支付宝 | 12.12.6、12.12.8、12.12.10、12.12.12 |
| 探针结果 | `H5WebViewController` 与 `PSDJsBridge` / `RVKJsBridge` Hook 成功 |
| 森林首页 | 新版顶层 `bubbles`、`userBaseInfo` 已确认 |
| 好友气泡 | `id`、`userId`、`collectStatus`、`overTime` 等字段已确认 |
| 好友排行榜 | `friendRanking`、`myself`、`totalDatas` 已确认 |
| 自动能量雨 | 已确认能识别下降中的能量并自动收取 |
| 自动赚能量（打地鼠玩法） | 已验证自动点击与正常结算；仅活动专用页面生效 |
| iOS 15.7 验证 | iPhone 13 Pro Max、支付宝 12.12.10；叶子面板可打开，自动收取的排行与好友状态查询正常 |
| iOS 15.0.1 验证 | iPhone X（A11，`arm64`）；通用 dylib 可通过 TrollFools 注入并正常使用 |
| iOS 14.2.1 验证 | iPhone 12 Pro Max（A14，`arm64e`）、支付宝 12.12.10；iOS 14 独立包注入及功能正常 |
| 巨魔真后台 | iOS 16.2 下配合 ImmortalizerJailed：后台可维持周期定时器与请求发起，但 H5/RPC 回包及实际收取不保证；切回森林首页后可恢复补跑 |

## 构建

需要完整 Xcode：

```sh
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer make
```

本地 v3.3.1 正式产物位于 `build/AntForestPort-v3.3.1.dylib` 与 `build/AntForestPort-v3.3.1-iOS14.dylib`。

GitHub Release 的通用 dylib 按 `AntForestPort-v3.3.1.dylib` 命名。

## 开发分支约定

- `main`：正式主干分支与发布线（当前为 v3.2.7 正式版）。
- `release/v2.8.3-1`：上一正式维护线。
- `release/v2.8.3-1-ios14`：iOS 14 独立兼容构建，单独发布，不影响 iOS 15+ 正式包。
- `feature/earn-energy-probe`：保留“赚能量”玩法的实验与诊断记录；已验证的自动点击逻辑已合入正式开发线。
- 后续每项新功能或缺陷修复均从独立 `feature/...` 或 `fix/...` 分支开发；真机验证后再合入新的 `release/...` 分支，避免实验代码影响稳定版。

## 反馈

- TG 讨论群：[iOS_AntFore](https://t.me/iOS_AntFore)，用于日常交流、使用讨论和问题收集。
- TG 频道：[AntFore](https://t.me/AntFore)，用于发布版本与项目动态。
- GitHub [Issues](../../issues) 用于提交可复现的问题、兼容性反馈和设备日志，便于持续跟踪处理。

### 获取 `[AntForestPort]` 设备控制台日志

1. 用数据线连接 iPhone，解锁设备并在 iPhone 上选择“信任此电脑”。
2. 在 Mac 打开“控制台”App，左侧选择该 iPhone，点击“开始流式传输”。
3. 在搜索框输入 `AntForestPort`。
4. 完全杀掉并重开支付宝，进入蚂蚁森林，并按需要点击右侧叶子按钮或开启自动收取。
5. 复制出现的 `[AntForestPort]` 行并附到 Issue。

也可在 Xcode 中打开 `Window → Devices and Simulators → 你的 iPhone → Open Console`，再搜索 `AntForestPort`。

正常注入时会看到：

```text
[AntForestPort] installed: view=1 appearance=1 response=1
```

请同时附上从启动支付宝到复现问题前后的相关行；不要提交账号、手机号、用户 ID 或能量球 ID 等敏感内容。

Issue 请附上：

- 设备型号与 CPU 架构
- iOS、支付宝、巨魔商店 TrollStore 与巨魔注入器 TrollFools 版本
- 注入方式
- `[AntForestPort]` 相关设备控制台日志
- 是否出现浮窗、是否闪退、是否能打开日志面板


## v3.3.0 源码清理说明

- 设置界面移除步数模拟入口与芭芭农场任务入口。
- 移除步数模拟面板、运行时 Hook 调用及编译源文件。
- 强制关闭旧版本遗留的芭芭农场自动任务偏好，避免升级后被旧设置重新启用。
- 蚂蚁庄园功能保持独立，不随芭芭农场清理而删除。
- 不包含广告等待绕过、奖励提前领取或规避平台检测的改动。

## GitHub Actions 云端编译

仓库已提供 `.github/workflows/build.yml`：

1. 将源码上传到 GitHub 仓库的 `main` 或 `master` 分支（也可在 Actions 页面手动运行）。
2. 打开仓库顶部的 **Actions** 标签页，选择 **Build AntForestPort**。
3. 等待 `Run source checks`、`Build arm64 + arm64e dylibs` 和 `Verify build products` 全部通过。
4. 在该次运行页面底部的 **Artifacts** 下载 `AntForestPort-v3.3.0-dylibs`。

工作流在 GitHub 托管的 macOS 15 runner 上使用预装 Xcode/iOS SDK 编译，并验证两个 dylib 都包含预期的通用架构。Artifacts 保留 14 天。当前工作流只编译和上传构建产物，不会自动发布 GitHub Release。
