#!/bin/sh
set -eu
FILE="antforest/AntForestManager.m"
grep -q 'UIApplicationDidEnterBackgroundNotification' "$FILE"
grep -q 'UIApplicationWillEnterForegroundNotification' "$FILE"
grep -q 'beginBackgroundTaskWithName:@"AntForestPort.FiniteWork"' "$FILE"
grep -q 'expirationHandler:' "$FILE"
grep -q 'AFEndFiniteBackgroundTask();' "$FILE"
# Finite execution must not be renewed or kept alive through silent audio.
! grep -q 'playBlankAudio' "$FILE"
echo "finite background execution checks passed"
