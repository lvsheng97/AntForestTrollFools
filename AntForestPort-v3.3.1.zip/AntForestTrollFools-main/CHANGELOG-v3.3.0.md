# AntForestPort v3.3.0 — source cleanup

## Included
- Removed the step-simulation settings panel and its runtime hook calls.
- Removed the StepSimulator source files from the build source list.
- Removed the Baba Farm settings switch and its bridge-driven task entry point.
- Force-disabled the legacy `enableAutoFarmTasks` preference during initialization so an old saved value cannot reactivate that feature.
- Kept Ant Manor as a separate feature; it is not removed with Baba Farm.
- Removed packet-probe dumps from the manual diagnostic-log copy output.
- Updated Makefile version metadata to v3.3.0.

## Not included
- No anti-detection or platform-risk-control evasion.
- No bypass of advertising, viewing, cooldown, or reward eligibility requirements.
- No acceleration or automation of third-party reward claims.
- No new cross-app background execution capability.

## Build verification
- Source-level shell tests pass in the supplied Linux workspace.
- A native iOS dylib build was not run: Apple's `xcrun` / iOS SDK and Xcode toolchain are not available in this environment. Build on a macOS GitHub Actions runner before installing.
