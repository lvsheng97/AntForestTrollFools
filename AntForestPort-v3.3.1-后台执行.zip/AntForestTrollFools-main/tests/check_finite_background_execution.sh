#!/bin/sh
set -eu
FILE="antforest/AntForestManager.m"
grep -q 'UIApplicationDidEnterBackgroundNotification' "$FILE"
grep -q 'UIApplicationWillEnterForegroundNotification' "$FILE"
grep -q 'beginBackgroundTaskWithName:@"AntForestPort.FiniteWork"' "$FILE"
grep -q 'expirationHandler:' "$FILE"
grep -q 'AFEndFiniteBackgroundTask();' "$FILE"
# Finite execution must not be renewed or kept alive through silent audio.
! grep -q 'playBlankAudio' "$FILE"
echo "finite background execution checks passed"
# User-facing opt-in must gate the finite background task; it must not claim permanent residency.
grep -q 'enableFiniteBackgroundExecution' antforest/AntForestManager.h
grep -q 'boolForKey:@"enableFiniteBackgroundExecution"' antforest/AntForestManager.m
grep -q '静态后台常驻（有限后台执行）' PortEntry.m
grep -q 'toggleFiniteBackgroundExecution:' PortEntry.m
grep -q 'manager.enableFiniteBackgroundExecution = \[defaults boolForKey:@"enableFiniteBackgroundExecution"\]' PortEntry.m
